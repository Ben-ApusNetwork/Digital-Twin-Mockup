const fs = require("node:fs/promises");
const path = require("node:path");
const os = require("node:os");
const { promisify } = require("node:util");
const { execFile } = require("node:child_process");
const { createHash } = require("node:crypto");

const execFileAsync = promisify(execFile);
const HOOK_DIR = __dirname;
const HOOK_STATE_DIR = path.join(HOOK_DIR, "state");
const PENDING_PATH = path.join(HOOK_STATE_DIR, "pending.json");
const META_PATH = path.join(HOOK_STATE_DIR, "meta.json");
const EVENTS_LOG_PATH = path.join(HOOK_STATE_DIR, "events.log");
const OPENCLAW_CONFIG_PATH = path.join(os.homedir(), ".openclaw", "openclaw.json");
const SKILL_DIR = path.join(os.homedir(), ".openclaw", "skills", "openclaw-memoryloop-demo");
const OBSERVER_SCRIPT = path.join(SKILL_DIR, "scripts", "instant_memory_feedback.py");
const VISION_SCRIPT = path.join(SKILL_DIR, "scripts", "vision_caption.py");
const OBSERVER_STATE = path.join(SKILL_DIR, "state", "live_demo.json");
const SIDECAR_MARKER = "SOURCE_ACCEPTED=";

function isTelegramEvent(event) {
  return event?.type === "message" && event?.context?.channelId === "telegram";
}

function isSidecarContent(text) {
  const trimmed = String(text || "").trim();
  return trimmed.startsWith(SIDECAR_MARKER) || trimmed.includes(`\n${SIDECAR_MARKER}`);
}

function pendingKeyFor(event) {
  const context = event?.context || {};
  const sessionKey = String(event?.sessionKey || "").trim();
  if (sessionKey) return `session:${sessionKey}`;

  const conversationId = String(context.conversationId || context.groupId || "").trim();
  if (conversationId) return `conversation:${context.channelId || "unknown"}:${conversationId}`;

  const peerId = String(context.from || context.to || context.senderId || "").trim();
  if (peerId) return `peer:${context.channelId || "unknown"}:${peerId}`;

  return `message:${context.channelId || "unknown"}:${context.messageId || "unknown"}`;
}

function cleanupTelegramEnvelope(text) {
  const raw = String(text || "").trim();
  if (!raw) return "";
  return raw.replace(/^\[[^\]]+\]\s*/u, "").trim();
}

function inboundTextFromContext(context) {
  const preferred = context?.bodyForAgent || context?.transcript || context?.body || context?.content || "";
  return cleanupTelegramEnvelope(preferred);
}

function titleFromText(text) {
  const singleLine = String(text || "").replace(/\s+/g, " ").trim();
  if (!singleLine) return "interaction";
  return singleLine.slice(0, 48);
}

function asArray(value) {
  if (Array.isArray(value)) return value;
  if (value && typeof value === "object") return [value];
  return [];
}

function candidateImageRef(entry, fallbackKind = "") {
  if (!entry || typeof entry !== "object") return null;
  const pathValue = entry.localPath || entry.filePath || entry.path || entry.downloadedPath || "";
  if (typeof pathValue === "string" && pathValue.trim()) {
    return { kind: "path", value: pathValue.trim() };
  }

  const urlValue = entry.url || entry.downloadUrl || entry.fileUrl || entry.href || "";
  if (typeof urlValue === "string" && urlValue.trim()) {
    return { kind: "url", value: urlValue.trim() };
  }

  const fileId = entry.file_id || entry.fileId || "";
  if (typeof fileId === "string" && fileId.trim() && (fallbackKind === "photo" || String(entry.mime_type || entry.mimeType || "").startsWith("image/"))) {
    return { kind: "telegram-file-id", value: fileId.trim() };
  }

  return null;
}

function extractImageReference(context) {
  const pools = [
    { value: context?.attachments, kind: "" },
    { value: context?.files, kind: "" },
    { value: context?.media, kind: "" },
    { value: context?.image, kind: "photo" },
    { value: context?.images, kind: "photo" },
    { value: context?.photo, kind: "photo" },
    { value: context?.photos, kind: "photo" },
    { value: context?.telegram?.message?.photo, kind: "photo" },
    { value: context?.telegram?.message?.document, kind: "" },
    { value: context?.raw?.message?.photo, kind: "photo" },
    { value: context?.raw?.message?.document, kind: "" },
  ];

  for (const pool of pools) {
    for (const entry of asArray(pool.value)) {
      const ref = candidateImageRef(entry, pool.kind);
      if (ref) return ref;
    }
  }

  return null;
}

async function ensureStateDir() {
  await fs.mkdir(HOOK_STATE_DIR, { recursive: true });
}

async function readJson(pathname, fallback) {
  try {
    return JSON.parse(await fs.readFile(pathname, "utf-8"));
  } catch {
    return fallback;
  }
}

async function writeJson(pathname, value) {
  await ensureStateDir();
  await fs.writeFile(pathname, JSON.stringify(value, null, 2), "utf-8");
}

async function appendEventLog(kind, details) {
  await ensureStateDir();
  const line = `${new Date().toISOString()} ${kind} ${JSON.stringify(details)}\n`;
  await fs.appendFile(EVENTS_LOG_PATH, line, "utf-8");
}

function sha1(text) {
  return createHash("sha1").update(text).digest("hex");
}

async function resolveTelegramBotToken() {
  const config = await readJson(OPENCLAW_CONFIG_PATH, {});
  const token = String(config?.channels?.telegram?.botToken || "").trim();
  if (!token) {
    throw new Error("telegram bot token missing from ~/.openclaw/openclaw.json");
  }
  return token;
}

async function resolveTelegramFileUrl(fileId) {
  const token = await resolveTelegramBotToken();
  const response = await fetch(`https://api.telegram.org/bot${token}/getFile?file_id=${encodeURIComponent(fileId)}`);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload?.ok === false || !payload?.result?.file_path) {
    const detail = payload?.description || payload?.error_code || response.status;
    throw new Error(`telegram getFile failed: ${detail}`);
  }
  return `https://api.telegram.org/file/bot${token}/${payload.result.file_path}`;
}

function resolveTelegramChatId(event, current) {
  const candidates = [
    event?.context?.conversationId,
    current?.conversationId,
    event?.context?.to,
    event?.context?.groupId,
  ];
  for (const value of candidates) {
    const raw = String(value || "").trim();
    if (!raw) continue;
    if (raw.startsWith("telegram:")) return raw.slice("telegram:".length);
    return raw;
  }
  return "";
}

async function sendTelegramSidecar(chatId, summary) {
  const token = await resolveTelegramBotToken();
  const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text: summary,
      disable_web_page_preview: true,
    }),
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload?.ok === false) {
    const detail = payload?.description || payload?.error_code || response.status;
    throw new Error(`telegram sendMessage failed: ${detail}`);
  }

  return payload;
}

async function runVisionCaption(imageRef, hintText) {
  if (!imageRef?.kind || !imageRef?.value) return "";

  try {
    const args = [VISION_SCRIPT];
    if (imageRef.kind === "path") {
      args.push("--image-path", imageRef.value);
    } else if (imageRef.kind === "url") {
      args.push("--image-url", imageRef.value);
    } else if (imageRef.kind === "telegram-file-id") {
      const url = await resolveTelegramFileUrl(imageRef.value);
      args.push("--image-url", url);
    } else {
      return "";
    }

    if (hintText.trim()) {
      args.push("--hint-text", hintText.trim());
    }

    const { stdout } = await execFileAsync("python3", args, {
      cwd: SKILL_DIR,
      maxBuffer: 1024 * 1024,
    });
    return String(stdout || "").trim();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    await appendEventLog("vision_failed", { reason: message, imageKind: imageRef.kind });
    return "";
  }
}

async function buildInboundObservation(context) {
  const text = inboundTextFromContext(context);
  const imageRef = extractImageReference(context);
  if (!imageRef) {
    return {
      sourceType: "interaction",
      userText: text,
      title: titleFromText(text),
    };
  }

  const visionCaption = await runVisionCaption(imageRef, text);
  const parts = [];
  if (text) parts.push(text);
  if (visionCaption) parts.push(visionCaption);
  const userText = parts.join("\n").trim() || "Uploaded image for taste memory audit.";
  const titleSeed = text || visionCaption || "image upload";

  return {
    sourceType: "image",
    userText,
    title: titleFromText(titleSeed),
  };
}

async function handlePreprocessed(event) {
  const inbound = await buildInboundObservation(event.context);
  const text = String(inbound.userText || "").trim();
  if (!text) return;
  if (inbound.sourceType === "interaction" && text.startsWith("/")) return;

  const pending = await readJson(PENDING_PATH, {});
  const key = pendingKeyFor(event);
  pending[key] = {
    userText: text,
    sourceType: inbound.sourceType,
    title: inbound.title,
    recordedAt: Date.now(),
    conversationId: event?.context?.conversationId || "",
    messageId: event?.context?.messageId || "",
  };
  await writeJson(PENDING_PATH, pending);
  await appendEventLog("preprocessed", {
    key,
    conversationId: event?.context?.conversationId || "",
    messageId: event?.context?.messageId || "",
    sourceType: inbound.sourceType,
    title: inbound.title,
  });
}

async function handleSent(event) {
  if (!event?.context?.success) return;
  const outbound = String(event?.context?.content || "").trim();
  if (!outbound) return;
  if (isSidecarContent(outbound)) return;

  const key = pendingKeyFor(event);
  const pending = await readJson(PENDING_PATH, {});
  const current = pending[key];
  if (!current?.userText) {
    await appendEventLog("sent_skipped_missing_pending", {
      key,
      conversationId: event?.context?.conversationId || "",
      messageId: event?.context?.messageId || "",
      outboundPreview: outbound.slice(0, 120),
    });
    return;
  }

  const meta = await readJson(META_PATH, {});
  const fingerprint = sha1(`${key}|${event?.context?.messageId || ""}|${outbound}`);
  if (meta[key] === fingerprint) {
    await appendEventLog("sent_skipped_duplicate", {
      key,
      conversationId: event?.context?.conversationId || "",
      messageId: event?.context?.messageId || "",
    });
    return;
  }

  try {
    const { stdout } = await execFileAsync(
      "python3",
      [
        OBSERVER_SCRIPT,
        "--state",
        OBSERVER_STATE,
        "observe",
        "--source-type",
        current.sourceType || "interaction",
        "--user-text",
        current.userText,
        "--assistant-text",
        outbound,
        "--title",
        current.title || "interaction",
      ],
      {
        cwd: SKILL_DIR,
        maxBuffer: 1024 * 1024,
      },
    );

    const summary = String(stdout || "").trim();
    if (!summary) {
      await appendEventLog("sent_skipped_empty_summary", {
        key,
        conversationId: event?.context?.conversationId || "",
        messageId: event?.context?.messageId || "",
      });
      return;
    }

    const chatId = resolveTelegramChatId(event, current);
    if (!chatId) {
      throw new Error("telegram chat id unavailable for sidecar delivery");
    }

    const result = await sendTelegramSidecar(chatId, summary);
    delete pending[key];
    meta[key] = fingerprint;
    await writeJson(PENDING_PATH, pending);
    await writeJson(META_PATH, meta);
    await appendEventLog("sent_delivered_summary", {
      key,
      conversationId: event?.context?.conversationId || current?.conversationId || "",
      messageId: String(result?.result?.message_id || ""),
      summaryPreview: summary.split("\n").slice(0, 2).join(" | "),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`[telegram-memory-sidecar] observe failed: ${message}`);
    await appendEventLog("sent_failed", {
      key,
      conversationId: event?.context?.conversationId || "",
      messageId: event?.context?.messageId || "",
      error: message,
    });
  }
}

const handler = async (event) => {
  if (!isTelegramEvent(event)) return;

  if (event.action === "preprocessed") {
    await handlePreprocessed(event);
    return;
  }

  if (event.action === "sent") {
    await handleSent(event);
  }
};

module.exports = handler;
module.exports.default = handler;
